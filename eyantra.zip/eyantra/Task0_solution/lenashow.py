import cv2
img = imread("lena.png",0)
cv2.imshow("lena", img)